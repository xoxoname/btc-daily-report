# constants.py
TELEGRAM_BOT_TOKEN = 'your_bot_token_here'
TELEGRAM_CHAT_ID = 1038440081
COINBASE_API_URL = 'https://api.coinbase.com/v2/prices/spot?currency=USD'